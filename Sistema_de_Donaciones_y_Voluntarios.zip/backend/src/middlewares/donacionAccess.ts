// src/middlewares/donacionAccess.ts
// ============================================================================
// Autorización propia del módulo Gestión de Donaciones.
// Reutiliza `verificarToken` (que deja el JWT decodificado en req.usuario) y
// valida el rol CANÓNICO del token. Nunca se acepta el rol ni el id desde el
// body/query. No modifica authMiddleware.ts.
// ============================================================================
import type { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/AppError';
import type { ActorDonacion, RolCanonico } from '../models/donacionModel';

const ROLES_CANONICOS: readonly RolCanonico[] = ['Administrador', 'Donante', 'Voluntario', 'Beneficiario'];

/** Extrae el actor autenticado del JWT ya verificado. */
export const actorDesdeRequest = (req: Request): ActorDonacion => {
  const u = req.usuario;
  const id = Number(u?.id_usuario);
  const roles = Array.isArray(u?.roles) ? u.roles.filter((r: unknown): r is RolCanonico => ROLES_CANONICOS.includes(r as RolCanonico)) : [];
  const legacy = u?.rol as RolCanonico | undefined;
  if (!roles.length && legacy && ROLES_CANONICOS.includes(legacy)) roles.push(legacy);
  // Las cuentas nuevas pueden registrar su primera donación; el rol se crea al confirmar.
  if (!roles.length && u) roles.push('Donante');
  const rol = roles.includes('Administrador') ? 'Administrador' : roles.includes('Voluntario') ? 'Voluntario' : roles.includes('Beneficiario') ? 'Beneficiario' : roles.includes('Donante') ? 'Donante' : undefined;
  if (!u || !Number.isInteger(id) || id <= 0 || !rol) {
    throw new AppError('Acceso denegado. Tu rol no tiene acceso a este módulo.', 403);
  }
  return { id_usuario: id, rol, roles, nombre: u.nombre };
};

/** Exige que el rol del JWT sea uno de los indicados. */
export const requerirRol =
  (...permitidos: RolCanonico[]) =>
  (req: Request, _res: Response, next: NextFunction): void => {
    try {
      const actor = actorDesdeRequest(req);
      if (!(actor.roles || [actor.rol]).some((rol) => permitidos.includes(rol))) {
        throw new AppError('Acceso denegado. No tienes permisos para esta acción.', 403);
      }
      next();
    } catch (err) {
      next(err);
    }
  };
