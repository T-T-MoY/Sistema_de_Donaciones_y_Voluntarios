/**
 * ============================================================================
 * ARCHIVO: UsuarioCard.tsx
 * Tarjeta individual de usuario. Funciona en desktop y móvil.
 * ============================================================================
 */

import type { Usuario } from '../../types/usuario.types';
import {
  obtenerId,
  getNombreCompleto,
  getIniciales,
  getEstado,
  esActivo,
  getRolesDisplay,
} from '../../types/usuario.types';

interface UsuarioCardProps {
  usuario: Usuario;
  onEdit: (usuario: Usuario) => void;
  onDelete: (id: number) => void;
}

/**
 * Color del badge de rol (solo presentación).
 */
const getRolBadgeClass = (rol?: string): string => {
  const r = (rol || '').toLowerCase();

  if (r === 'admin' || r === 'administrador') {
    return 'border-primary/25 bg-primary-soft text-primary';
  }
  if (r === 'donante' || r === 'cliente') {
    return 'border-accent/35 bg-accent-soft text-accent-text';
  }
  if (r === 'empleado' || r === 'voluntario') {
    return 'border-success/30 bg-success-soft text-success';
  }
  if (r === 'beneficiario') {
    return 'border-info/30 bg-info-soft text-info';
  }
  return 'border-border bg-surface text-text-muted';
};

const getAvatarUrl = (fotoUrl?: string | null): string | null => {
  if (!fotoUrl) return null;
  if (fotoUrl.startsWith('http://') || fotoUrl.startsWith('https://')) return fotoUrl;
  const baseUrl = (import.meta.env.VITE_API_URL || 'http://localhost:4000/api').replace(/\/api\/?$/, '');
  return `${baseUrl}${fotoUrl.startsWith('/') ? '' : '/'}${fotoUrl}`;
};

export const UsuarioCard = ({ usuario, onEdit, onDelete }: UsuarioCardProps) => {
  const estado = getEstado(usuario);
  const activo = esActivo(usuario);
  const id = obtenerId(usuario);
  const foto = getAvatarUrl(usuario.foto_url as string | null);

  return (
    <div className="lift group relative overflow-hidden rounded-2xl border border-border bg-surface-elevated p-5 shadow-soft hover:border-accent/45 hover:shadow-lift">
      <span
        aria-hidden="true"
        className="absolute inset-x-0 top-0 h-[2px] w-0 bg-linear-to-r from-accent to-accent/30 transition-[width] duration-300 ease-out-soft group-hover:w-full"
      />

      {/* Cabecera: avatar + nombre + correo */}
      <div className="mb-4 flex items-start gap-3">
        {foto ? (
          <img
            src={foto}
            alt={getNombreCompleto(usuario)}
            className="h-11 w-11 shrink-0 rounded-xl object-cover ring-1 ring-border shadow-soft"
          />
        ) : (
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary-soft text-sm font-bold text-primary ring-1 ring-primary/15 transition-colors duration-300 group-hover:bg-primary group-hover:text-on-primary">
            {getIniciales(usuario)}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <h3
            className="truncate font-display text-sm font-bold tracking-[-0.01em] text-text"
            title={getNombreCompleto(usuario)}
          >
            {getNombreCompleto(usuario)}
          </h3>
          <p
            className="truncate text-xs text-text-muted"
            title={usuario.correo}
          >
            {usuario.correo || 'sin correo'}
          </p>
        </div>
      </div>

      {/* Rol + Estado */}
      <div className="mb-4 grid grid-cols-2 gap-3 text-xs">
        <div className="min-w-0">
          <p className="mb-1.5 text-[9.5px] font-bold uppercase tracking-[0.12em] text-text-subtle">
            Rol
          </p>
          <div className="flex max-w-full flex-wrap items-center gap-1" aria-label={`Roles: ${getRolesDisplay(usuario.roles, usuario.rol).join(', ')}`}>
            {getRolesDisplay(usuario.roles, usuario.rol).map((rol) => (
              <span
                key={rol}
                className={`inline-flex max-w-full items-center whitespace-nowrap rounded-full border px-2 py-1 text-[9px] font-bold uppercase leading-none tracking-[0.04em] ${getRolBadgeClass(rol)}`}
              >
                {rol}
              </span>
            ))}
          </div>
        </div>
        <div>
          <p className="mb-1.5 text-[9.5px] font-bold uppercase tracking-[0.12em] text-text-subtle">
            Estado
          </p>
          <span
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10.5px] font-bold ${
              activo
                ? 'border-success/30 bg-success-soft text-success'
                : 'border-error/30 bg-error-soft text-error'
            }`}
          >
            <span
              className={`h-1.5 w-1.5 rounded-full ${activo ? 'bg-success' : 'bg-error'}`}
            />
            {estado}
          </span>
        </div>
      </div>

      {/* Botones */}
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => onEdit(usuario)}
          className="press flex-1 rounded-xl border border-border bg-surface py-2 text-[11.5px] font-bold uppercase tracking-[0.06em] text-text-muted hover:border-accent/50 hover:bg-accent-soft hover:text-text"
        >
          Editar
        </button>
        <button
          type="button"
          onClick={() => id !== undefined && onDelete(Number(id))}
          className="press flex-1 rounded-xl border border-border bg-surface py-2 text-[11.5px] font-bold uppercase tracking-[0.06em] text-error hover:border-error/40 hover:bg-error-soft"
        >
          Eliminar
        </button>
      </div>
    </div>
  );
};

export default UsuarioCard;
